<?php

require_once 'database.php';
session_start();

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';
$senha = $data['senha'] ?? '';

$sql = "SELECT * FROM usuario WHERE email = ? LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($senha, $user['senha'])) {
    $_SESSION['usuario_email'] = $user['email'];
    $_SESSION['usuario_nome'] = $user['nome']; 
    $_SESSION['usuario_id'] = $user['id'];
    $_SESSION['tipo_usuario'] = $user['tipo_usuario'];
    echo json_encode(["success" => true,
    "tipo" => $user['tipo_usuario']]);
    
}else{
    echo json_encode(["success" => false, "message" => "Dados inválidos"]);
} 