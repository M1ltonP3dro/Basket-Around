<?php
session_start();
require_once "../Back/database.php";

if (!isset($_SESSION['usuario_email'])) {
    header('Location: ../pages/home.php');
    exit;
}

$quadra_id = $_POST['quadra_id'] ?? null;
$msg = "";

if (!$quadra_id) {
    header('Location: home.php');
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['horario_id'])) {
    $horario_id = $_POST['horario_id'];
    $usuario_id = $_SESSION['usuario_id'];

    try {
        $pdo->beginTransaction();

        $sqlReserva = "INSERT INTO reserva (usuario_id, horario_id, reserva_confirmacao) 
                       VALUES (:u_id, :h_id, 'confirmada')";
        $stmtRes = $pdo->prepare($sqlReserva);
        $stmtRes->execute([':u_id' => $usuario_id, ':h_id' => $horario_id]);

        $sqlUpd = "UPDATE horario SET reserva_estado = 'reservado' WHERE id = :h_id";
        $stmtUpd = $pdo->prepare($sqlUpd);
        $stmtUpd->execute([':h_id' => $horario_id]);

        $pdo->commit();
         $showModal = true;
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Erro ao agendar: " . $e->getMessage();
    }
}

$stmt = $pdo->prepare("SELECT * FROM quadra WHERE id = :id");
$stmt->execute([':id' => $quadra_id]);
$quadra = $stmt->fetch(PDO::FETCH_ASSOC);

$stmtH = $pdo->prepare("SELECT * FROM horario WHERE q_id = :q_id AND reserva_estado = 'disponível'");
$stmtH->execute([':q_id' => $quadra_id]);
$horarios = $stmtH->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../">
    <title>Agendar Jogo <?= htmlspecialchars($quadra['q_nome']) ?></title>
    <link rel="stylesheet" href="../styles/agendar.css">
</head>
<body>
    <h1>Reservando: <?= htmlspecialchars($quadra['q_nome']) ?></h1>
    <div class="container">
    <form method="POST" action="agendar.php">
        <input type="hidden" name="quadra_id" value="<?= htmlspecialchars($quadra_id) ?>">

        <label>Escolha um horário disponível:</label>
        <select name="horario_id" required>
            <option value="">-- Selecione um horário --</option>
            <?php foreach ($horarios as $h): ?>
                <option value="<?= $h['id'] ?>">
                    <?= htmlspecialchars($h['inicio_tempo']) ?> até <?= htmlspecialchars($h['final_tempo']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Confirmar Agendamento</button>
        <button onclick="window.location.href='home.php'">Sair</button>
    </form>
    </div>
    <?php if (isset($showModal)): ?>
<div id="modalSucesso" class="modal-overlay">
    <div class="modal-content">
        <div class="ball-icon"></div>
        <h2>Agendado com Sucesso!</h2>
        <p>Prepare-se para o jogo. Redirecionando...</p>
        <div class="progress-bar"></div>
    </div>
</div>

<style>
    .modal-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.85); display: flex; align-items: center; justify-content: center; z-index: 1000;
    }
    .modal-content {
        background: #1a1a1a; color: white; padding: 40px; border-radius: 15px;
        border: 2px solid #ff6b00; text-align: center; position: relative; width: 300px;
    }
    .ball-icon { font-size: 50px; margin-bottom: 10px; animation: bounce 0.5s infinite alternate; }
    .progress-bar {
        height: 4px; background: #ff6b00; width: 100%; position: absolute; bottom: 0; left: 0;
        animation: timer 5s linear forwards;
    }
    @keyframes bounce { from { transform: translateY(0); } to { transform: translateY(-10px); } }
    @keyframes timer { from { width: 100%; } to { width: 0%; } }
</style>

<script>
    setTimeout(() => {
        window.location.href = 'home.php';
    }, 5000);
</script>
<?php endif; ?>


</html>