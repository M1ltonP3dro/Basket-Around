<?php
require_once 'database.php';

header('Content-Type: application/json; charset=utf-8');

$inputData = json_decode(file_get_contents("php://input"), true);

if (!$inputData || !isset($inputData['localizacao'])) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Os dados não foram enviados corretamente."
    ]);
    exit;
}

$localizacao = $inputData['localizacao'];

$sql = "SELECT * FROM quadra WHERE localizacao LIKE ?";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$localizacao%"]);

$quadras = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "status" => "sucesso",
    "dados" => $quadras
]);
