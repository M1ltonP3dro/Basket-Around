-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19/01/2026 às 11:13
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `basket_around`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacao`
--

CREATE TABLE `avaliacao` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `q_id` int(11) DEFAULT NULL,
  `estrelas_avaliacao` int(11) DEFAULT NULL CHECK (`estrelas_avaliacao` >= 1 and `estrelas_avaliacao` <= 5),
  `comentario` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `horario`
--

CREATE TABLE `horario` (
  `id` int(11) NOT NULL,
  `q_id` int(11) DEFAULT NULL,
  `inicio_tempo` time DEFAULT NULL,
  `final_tempo` time DEFAULT NULL,
  `reserva_estado` enum('disponível','reservado') DEFAULT NULL,
  `data_dia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `horario`
--

INSERT INTO `horario` (`id`, `q_id`, `inicio_tempo`, `final_tempo`, `reserva_estado`, `data_dia`) VALUES
(1, 1, '14:30:00', '16:30:30', 'reservado', '2026-01-19'),
(2, 1, '12:30:00', '14:30:00', 'reservado', '2026-01-20'),
(3, 1, '12:30:00', '14:30:00', 'reservado', '2026-01-20'),
(4, 2, '08:15:00', '09:16:00', 'reservado', '2026-01-19'),
(5, 5, '09:57:00', '11:57:00', 'reservado', '2026-01-22'),
(6, 3, '10:37:00', '12:37:00', 'reservado', '2026-01-26'),
(7, 3, '07:00:00', '08:00:00', 'disponível', '2026-01-20'),
(8, 1, '08:00:00', '10:00:00', 'disponível', '2026-01-22'),
(9, 1, '08:01:00', '10:01:00', 'reservado', '2026-01-26'),
(10, 3, '09:00:00', '12:00:00', 'disponível', '2026-01-20'),
(11, 5, '11:00:00', '13:00:00', 'disponível', '2026-01-21'),
(12, 6, '10:30:00', '12:30:00', 'reservado', '2026-01-30'),
(13, 6, '10:30:00', '12:30:00', 'reservado', '2026-01-30'),
(14, 5, '10:30:00', '12:30:00', 'reservado', '2026-01-20'),
(15, 5, '10:30:00', '12:30:00', 'disponível', '2026-01-20'),
(16, 2, '10:30:00', '12:30:00', 'reservado', '2026-01-20'),
(17, 6, '10:30:00', '12:30:00', 'reservado', '2026-01-20'),
(18, 5, '10:30:00', '12:30:00', 'reservado', '2026-01-20'),
(19, 2, '14:00:00', '16:00:00', 'reservado', '2026-01-21');

-- --------------------------------------------------------

--
-- Estrutura para tabela `quadra`
--

CREATE TABLE `quadra` (
  `id` int(11) NOT NULL,
  `q_nome` varchar(150) DEFAULT NULL,
  `localizacao` varchar(255) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `proprietario_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `quadra`
--

INSERT INTO `quadra` (`id`, `q_nome`, `localizacao`, `descricao`, `proprietario_id`) VALUES
(1, 'quadra da Africell', 'Rangel', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', NULL),
(2, 'Quadra da Filda', 'Viana', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', NULL),
(3, 'Arena do Kilamba', 'Kilamba', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', 52),
(4, 'Quadra do Benfica', 'Belas', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', 52),
(5, 'Arena Kwanza', 'Urbanização nova vida', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', 52),
(6, 'Pavilhão da Cidadela', 'Luanda', 'Quadra aberta, com tabelas em ótimo estado de conservação. Ideal para qualquer jogador', 52);

-- --------------------------------------------------------

--
-- Estrutura para tabela `reserva`
--

CREATE TABLE `reserva` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `horario_id` int(11) DEFAULT NULL,
  `reserva_confirmacao` enum('confirmada','cancelada') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `reserva`
--

INSERT INTO `reserva` (`id`, `usuario_id`, `horario_id`, `reserva_confirmacao`) VALUES
(4, 52, 1, 'cancelada'),
(5, 46, 1, 'cancelada'),
(6, 46, 1, 'cancelada'),
(7, 46, 2, 'confirmada'),
(8, 46, 5, 'confirmada'),
(9, 46, 4, 'confirmada'),
(10, 56, 3, 'confirmada'),
(11, 56, 6, 'confirmada'),
(12, 57, 14, 'confirmada'),
(13, 57, 18, 'confirmada'),
(14, 46, 16, 'confirmada'),
(15, 46, 13, 'confirmada'),
(16, 46, 12, 'confirmada'),
(17, 57, 19, 'confirmada'),
(18, 46, 17, 'confirmada'),
(19, 46, 9, 'confirmada');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `tipo_usuario` enum('Jogador','Admin') NOT NULL DEFAULT 'Jogador',
  `data_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `senha`, `tipo_usuario`, `data_registro`) VALUES
(37, 'Hélvio Coimbra', 'tchaba@gmail.com', '$2y$10$.ag0ZO1G6Tp994Yp3dKtQO6g0j/Q/.qhp8yqZ0lj4PLTfxEBKKcPa', 'Jogador', '2026-01-15 01:14:32'),
(46, 'Manuel Salvador', 'mms@gmail.com', '$2y$10$2ZvyXq6kcezuOAiaOtbMo.hKfmW5LXgSFvrhoXI0kSAFM3TiKN6ue', 'Jogador', '2026-01-15 07:50:56'),
(50, 'Kélcio Palma', 'kc@gmail.com', '$2y$10$aCnm6kvAckODDSlnpaEOyuJNYSkdUrZ5Jw8SSdRd5MlHMIWqxSHjO', 'Jogador', '2026-01-15 08:11:50'),
(52, 'Milton Gaspar', 'mp4@gmail.com', '$2y$10$SbK2w7dH.Ou1t45AkmGT1OWx0Vw8dqcGLyviT53NI16P90I8S1/fS', 'Admin', '2026-01-15 08:28:46'),
(55, 'Teófilo Félix', 'tf@gmail.com', '$2y$10$FU1neyYPxbHIwcIwcIzvb.LS8QVb3LUFei3CwO4hmHNv3RqlUpPL2', 'Jogador', '2026-01-16 11:51:09'),
(56, 'Fábio Policarpo', 'f4@gmail.com', '$2y$10$HViNpxmT9nR6LCUfcQag.u2J0O.W4Rr/YJ8pZ4GvMJ5/NrqNCbwJS', 'Jogador', '2026-01-19 04:38:42'),
(57, 'Luís Gaspar', 'monge4nelar@gmail', '$2y$10$Rx9xT5UT6OwBiECoRn4kwuVvzSu9ukxQjIRMmrWvgk41qA9RXL0FW', 'Jogador', '2026-01-19 05:07:26');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `q_id` (`q_id`);

--
-- Índices de tabela `horario`
--
ALTER TABLE `horario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `q_id` (`q_id`);

--
-- Índices de tabela `quadra`
--
ALTER TABLE `quadra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proprietario_id` (`proprietario_id`);

--
-- Índices de tabela `reserva`
--
ALTER TABLE `reserva`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `horario_id` (`horario_id`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `horario`
--
ALTER TABLE `horario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `quadra`
--
ALTER TABLE `quadra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `reserva`
--
ALTER TABLE `reserva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD CONSTRAINT `avaliacao_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  ADD CONSTRAINT `avaliacao_ibfk_2` FOREIGN KEY (`q_id`) REFERENCES `quadra` (`id`);

--
-- Restrições para tabelas `horario`
--
ALTER TABLE `horario`
  ADD CONSTRAINT `horario_ibfk_1` FOREIGN KEY (`q_id`) REFERENCES `quadra` (`id`);

--
-- Restrições para tabelas `quadra`
--
ALTER TABLE `quadra`
  ADD CONSTRAINT `quadra_ibfk_1` FOREIGN KEY (`proprietario_id`) REFERENCES `usuario` (`id`);

--
-- Restrições para tabelas `reserva`
--
ALTER TABLE `reserva`
  ADD CONSTRAINT `reserva_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  ADD CONSTRAINT `reserva_ibfk_2` FOREIGN KEY (`horario_id`) REFERENCES `horario` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
