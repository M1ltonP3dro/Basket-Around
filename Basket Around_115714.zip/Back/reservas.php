<?php
  session_start();
  require_once "../Back/database.php";
  
  if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'Admin') {
      header("Location: ../pages/log.html");
      exit;
  }
  
try{
     
    
    
    $query = "SELECT 
                q.q_nome, 
                q.localizacao, 
                h.data_dia, 
                h.inicio_tempo, 
                h.final_tempo,
                r.reserva_confirmacao,
                u.nome as usuario_nome
              FROM reserva r
              JOIN horario h ON r.horario_id = h.id
              JOIN quadra q ON h.q_id = q.id
              JOIN usuario u ON r.usuario_id = u.id
              WHERE r.reserva_confirmacao = 'confirmada'
              ORDER BY h.data_dia DESC, h.inicio_tempo ASC";
              
    $stmt = $pdo->query($query);
    $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro de conexão: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Reservas - Basket Around</title>
    <style>
        :root {
            --primary-orange: #ff6b00;
            --dark-grey: #1a1a1a;
            --light-grey: #f4f4f4;
            --accent-blue: #2d5a88;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--light-grey);
            margin: 0;
            padding: 20px;
            background: linear-gradient(rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.85));
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        header {
            background-color: var(--dark-grey);
            color: white;
            padding: 1rem;
            border-radius: 8px 8px 0 0;
            border-bottom: 4px solid var(--primary-orange);
            text-align: center;
        }

        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
            
        }

        .reserva-card {
            border-radius: 8px;
            box-shadow: 0 4px 20px orangered;
            overflow: hidden;
            color: white;
            border-left: 5px solid var(--primary-orange);
            transition: transform 0.2s;
        }

        .reserva-card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: rgba(0,0,0, 0.2);
            padding: 15px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
        }

        .card-body {
            padding: 15px;
        }

        .info-row {
            margin-bottom: 8px;
            font-size: 0.9em;
        }

        .label {
            color: var(--accent-blue);
            font-weight: bold;
        }

        .badge {
            background: var(--primary-orange);
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.8em;
        }

        .empty-state {
            text-align: center;
            padding: 50px;
            color: #888;
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1> Basket Around - Jogos Marcados</h1>
        <a style="color:orangered; text-decoration:none;" href="../pages/dash.php">Voltar</a>
    </header>

    <div class="card-container">
        <?php if (count($reservas) > 0): ?>
            <?php foreach ($reservas as $res): ?>
                <div class="reserva-card">
                    <div class="card-header">
                        <span><?= htmlspecialchars($res['q_nome']) ?></span>
                        <span class="badge">Confirmado</span>
                    </div>
                    <div class="card-body">
                        <div class="info-row">
                            <span class="label"> Local:</span> <?= htmlspecialchars($res['localizacao']) ?>
                        </div>
                        <div class="info-row">
                            <span class="label"> Data:</span> <?= date('d/m/Y', strtotime($res['data_dia'])) ?>
                        </div>
                        <div class="info-row">
                            <span class="label"> Horário:</span> <?= $res['inicio_tempo'] ?> às <?= $res['final_tempo'] ?>
                        </div>
                        <div class="info-row">
                            <span class="label"> Atleta:</span> <?= htmlspecialchars($res['usuario_nome']) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <p>Nenhuma reserva confirmada no momento.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
