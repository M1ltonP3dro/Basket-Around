<?php
require_once 'database.php';

if(!$pdo){
    echo json_encode(["status " => "erro", "mensagem" => "Problema ao conectar com a base de dados."]);
    exit();
}
else{
    $data = json_decode(file_get_contents('php://input'),true);
    if(!$data){
        echo json_encode(["status" => "erro", "mensagem" => "erro ao receber os dados."]);
        exit();
    }
    else{
        $nome = $data['nome'];
        $email = $data['email'];
        $senha = $data['senha'];
        
        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $insert = "INSERT into usuario(nome, email, senha)VALUES(?, ?, ?)";
        $stmt_user = $pdo->prepare($insert);
        $stmt_user->execute([$nome, $email, $hash]);

        echo json_encode([
            "status" => "sucesso",
            "mensagem" => "sucesso ao enviar os dados",
            "dados" => [
                "nome" => "$nome",
                "email" => "$email",
                "senha"=> "$senha"
            ]
        ]); 
    }  
}
?>