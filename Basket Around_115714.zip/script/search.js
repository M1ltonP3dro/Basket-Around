
async function carregarQuadras() {
    const response = await fetch('../Back/search.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            localizacao: ""
        })
    });

    const result = await response.json();

    if (result.status === "sucesso") {
        const container = document.getElementById("");
        container.innerHTML = "";

        result.dados.forEach(quadra => {
            container.innerHTML += `
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">${quadra.nome}</h5>
                            <p class="card-text">
                                 ${quadra.localizacao}<br>
                                 Tipo: ${quadra.tipo}
                            </p>
                        </div>
                    </div>
                </div>
            `;
        });
    }
}

carregarQuadras();
// document.getElementById("form").addEventListener("submit", function(event){
//     event.preventDefault();
//     pesquisarQuadra();
// });
// async  function pesquisarQuadra(){
//     const search_data = {
//         localizacao: localizacao.value 
//     };
//     try {
//        const input_json = await fetch("../Back/search.php", {
//             method: "POST",
//             headers: { 'Content-Type': 'application/json'},
//             body: JSON.stringify(search_data)
//         });
//        const input_response = await input_json.text();

//         if (input_response.error === "sucesso") {
//             console.log(input_response.mensagem)
//         } else {
//             console.log(input_response.mensagem)
//         }
//     } catch (error) {
//         console.log(error)
//     }  
// }