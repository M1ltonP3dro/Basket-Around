 let formulario_modo = "signup"; 
    
const signup_btn = document.getElementById('sign-up-btn');
const signin_btn = document.getElementById('sign-in-btn');
const nameField = document.getElementById('nameField');
const title = document.getElementById('Title');
const another_title = document.getElementById('another_title');

const nomeInput = document.getElementById('nome');
const emailInput = document.getElementById('email');
const senhaInput = document.getElementById('senha');

function showToast(mensagem, tipo = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.innerHTML = `<span>${mensagem}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}

signin_btn.addEventListener('click', () => {
    nameField.style.maxHeight = "0";
    title.innerHTML = "Sign In";
    formulario_modo = "signin";
    another_title.innerHTML = "Entrar";
    signup_btn.classList.add("disable");
    signin_btn.classList.remove("disable");
    nomeInput.required = false;
});

signup_btn.addEventListener('click', () => {
    formulario_modo = "signup";
    nameField.style.maxHeight = "55px";
    title.innerHTML = "Sign Up";
    another_title.innerHTML = "Enviar";
    signup_btn.classList.remove("disable");
    signin_btn.classList.add("disable");
    nomeInput.required = true;
});

document.getElementById("form").addEventListener("submit", async function (event){
    event.preventDefault();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (formulario_modo === "signup" && nomeInput.value.trim().length < 3) {
        showToast("O nome deve ter pelo menos 3 caracteres.", "error");
        return;
    }

    if (!emailRegex.test(emailInput.value)) {
        showToast("Por favor, insira um e-mail válido.", "error");
        return;
    }

    if (senhaInput.value.length < 8) {
        showToast("A senha deve ter no mínimo 8 caracteres.", "error");
        return;
    }

    if(formulario_modo === "signup"){
        await EnviarDados();
    } else {
        await SignIn();
    }
});

async function EnviarDados(){
    const user_data = {
        nome: nomeInput.value,
        email: emailInput.value,
        senha: senhaInput.value
    };
    try {
        const response = await fetch("../Back/receptor.php", { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user_data)
        });
        
        const response_json = await response.json();
        
        if(response_json.status === 'sucesso'){
            showToast("Cadastro realizado com sucesso!", "success");
            setTimeout(() => signin_btn.click(), 1000); 
        } else {
            showToast("Erro: " + response_json.mensagem, "error");
        }
    } catch(err) {
        showToast("Erro na conexão com o servidor.", "error");
    }
}

async function SignIn(){
    const signin_data = {
        email: emailInput.value,
        senha: senhaInput.value
    };
    try {
        const response = await fetch("../Back/session.php", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(signin_data)
        });
        
        const response2 = await response.json();
        if(response2.success === true){
            showToast("Login bem-sucedido!", "success");
            setTimeout(() => {
                window.location.href = (response2.tipo === "Admin") ? "dash.php" : "home.php";
            }, 1000);
        } else {
            showToast("Email ou senha inválidos!", "error");
        }
    } catch(err) {
        showToast("Erro ao processar login.", "error");
    }
}
