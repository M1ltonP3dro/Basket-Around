<?php
require_once  'databse.php';

$data = json_decode(file_get_contents('php://input'),true);

if(!$data){
    echo json_encode([
        "status" => "erro",
        "mensagem" => "erro ao enviar os dados"
    ]);
    exit();
}else{
    $nome = $data['name'];
    $email = $data['email'];
    $senha = $data['password'];

    $insert = "INSERT into usuario(nome, email, senha)VALUES(?, ?, ?)";
    $stmt_user = $pdo->prepare($insert);
     $stmt_user->execute([$nome, $email, $senha]);

    echo json_encode ([
        "status" => "sucesso",
        "mensagem" => "sucesso ao enviar os dados",
        "dados" => "$data"
    ]); 
}
