<?php
session_start();
require_once "../Back/database.php";

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'Jogador') {
    header("Location: ../pages/log.html");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$msg = "";
$tipo_msg = "";

$quadras = $pdo->query("
    SELECT id, q_nome, localizacao 
    FROM quadra
")->fetchAll(PDO::FETCH_ASSOC);

$horarios = $pdo->query("
    SELECT * FROM horario
")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $horario_id = $_POST['horario_id'] ?? null;

    if (!$horario_id) {
        $msg = "Selecione um horário válido.";
        $tipo_msg = "erro";
    } else {

        $check = $pdo->prepare("
            SELECT reserva_estado 
            FROM horario 
            WHERE id = ?
        ");
        $check->execute([$horario_id]);
        $estado = $check->fetchColumn();

        if ($estado !== 'disponível') {
            $msg = "Este horário já foi reservado.";
            $tipo_msg = "erro";
        } else {

            $stmt = $pdo->prepare("
                INSERT INTO reserva (usuario_id, horario_id, reserva_confirmacao)
                VALUES (?, ?, 'confirmada')
            ");
            $stmt->execute([$usuario_id, $horario_id]);

            $upd = $pdo->prepare("
                UPDATE horario 
                SET reserva_estado = 'reservado'
                WHERE id = ?
            ");
            $upd->execute([$horario_id]);

            $msg = "Reserva confirmada com sucesso!";
            $tipo_msg = "sucesso";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../Assets/IMG/1764843175038.ico">
    <title>Reservar Quadra</title>
    <link rel="stylesheet" href="../styles/agendar.css">
</head>
<body>

<div class="container">
    <h1>Reservar Quadra</h1>

    <?php if ($msg): ?>
        <div class="mensagem <?= $tipo_msg ?>"><?= $msg ?></div>
    <?php endif; ?>

    <form method="POST">

        <label>Quadra</label>
        <select id="quadra">
            <option value="">Selecione</option>
            <?php foreach ($quadras as $q): ?>
                <option value="<?= $q['id'] ?>">
                    <?= $q['q_nome'] ?> - <?= $q['localizacao'] ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Horário disponível</label>
        <select name="horario_id" id="horario" required>
            <option value="">Selecione</option>
            <?php foreach ($horarios as $h): ?>
                <option 
                    value="<?= $h['id'] ?>"
                    data-quadra="<?= $h['q_id'] ?>"
                    data-data="<?= $h['data_dia'] ?>"
                    data-estado="<?= $h['reserva_estado'] ?>"
                >
                    <?= $h['inicio_tempo'] ?> - <?= $h['final_tempo'] ?> (<?= $h['data_dia'] ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <button>Reservar</button>
    </form>
</div>

<script>
const quadra = document.getElementById('quadra');
const horario = document.getElementById('horario');

function filtrarHorarios() {
    const q = quadra.value;

    [...horario.options].forEach(opt => {
        if (!opt.value) return;

        const pertence = opt.dataset.quadra === q;
        const livre = opt.dataset.estado === 'disponível';

        opt.hidden = !(pertence && livre);
    });
}

quadra.addEventListener('change', filtrarHorarios);
</script>

</body>
</html>
