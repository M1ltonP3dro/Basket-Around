<?php
session_start();
require_once "../Back/database.php";
if (!isset($_SESSION['usuario_email'])) {
    header('Location: index.html');
    exit;
}


$quadras = [];
$pesquisa = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $pesquisa = trim($_POST['localizacao']);

    $sql = "SELECT * FROM quadra 
            WHERE localizacao LIKE :loc";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":loc", "%$pesquisa%");
    $stmt->execute();

    $quadras = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../Assets/IMG/1764843175038.ico">
    <title>Basket Around | Home</title>
    <link rel="stylesheet" href="../styles/home.css">
</head>
<body>

<header class="top-bar">
    <h1>Basket <span>Around</span></h1>

    <nav>
        <span>Olá, <?= htmlspecialchars($_SESSION['usuario_nome']) ?></span>
        <a href="../Back/logout.php" class="logout">Sair</a>
    </nav>
</header>

<main class="home-container">

    <!-- Pesquisa -->
    <section class="search-section">
        <h2>Encontre uma quadra perto de você</h2>

        <form method="POST">
            <input  type="text"  name="localizacao" 
             placeholder="Ex: Luanda, Talatona"
            value="<?= htmlspecialchars($pesquisa) ?>"
                required >
            <button type="submit">Pesquisar</button>
        </form>
    </section>

    <section class="results-section">
        <h2>Recomendações</h2>

        <?php if ($_SERVER["REQUEST_METHOD"] === "POST"): ?>

            <?php if (count($quadras) > 0): ?>
                <?php foreach ($quadras as $q): ?>
                    <div class="court-card">
                        <h3><?= htmlspecialchars($q['q_nome']) ?></h3>
                        <p><strong>Localização:</strong> <?= htmlspecialchars($q['localizacao']) ?></p>
                        <p><strong>Descrição:</strong> <?= htmlspecialchars($q['descricao']) ?></p>

                        <form action="agendar.php" method="POST">
                            <input type="hidden" name="quadra_id" value="<?= $q['id'] ?>">
                            <button type="submit">Agendar jogo</button>
                        </form>
                    </div>
                <?php endforeach; ?>

            <?php else: ?>
                <p class="no-results">
                    Nenhuma quadra encontrada para essa localização.
                </p>
            <?php endif; ?>

        <?php endif; ?>
    </section>

</main>

</body>
</html>
