<?php
session_start();
require_once "../Back/database.php";

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'Admin') {
    header("Location: ../pages/log.html");
    exit;
}

$mensagem = "";

$quadras = $pdo->query("SELECT id, q_nome FROM quadra")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $q_id = $_POST['q_id'];
    $data_dia = $_POST['data_dia'];
    $inicio = $_POST['inicio_tempo'];
    $fim = $_POST['final_tempo'];

    if (!empty($q_id) && !empty($data_dia) && !empty($inicio) && !empty($fim)) {
        $sql = "INSERT INTO horario (q_id, data_dia, inicio_tempo, final_tempo, reserva_estado) 
                VALUES (?, ?, ?, ?, 'disponível')";
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute([$q_id, $data_dia, $inicio, $fim])) {
            $mensagem = "<p class='sucesso'>Horário adicionado com sucesso!</p>";
        } else {
            $mensagem = "<p class='erro'>Erro ao adicionar horário.</p>";
        }
    } else {
        $mensagem = "<p class='erro'>Por favor, preencha todos os campos.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <title>Admin | Adicionar Horário</title>
    <link rel="stylesheet" href="../styles/dash.css"> </head>
<body>

<div class="container">
    <header>
        <h1>Adicionar <span>Disponibilidade</span></h1>
        <a href="dash.php" class="acoes">Voltar ao Painel</a>
        <a href="../Back/logout.php">Sair</a>
    </header>

    <?= $mensagem ?>

    <form method="POST" class="form-admin">
        <label>Selecionar Quadra:</label>
        <select name="q_id" required>
            <option value="">-- Escolha a Quadra --</option>
            <?php foreach ($quadras as $q): ?>
                <option value="<?= $q['id'] ?>"><?= htmlspecialchars($q['q_nome']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Data do Jogo:</label>
        <input type="date" name="data_dia" required min="<?= date('Y-m-d') ?>">

        <label>Hora de Início:</label>
        <input type="time" name="inicio_tempo" required>

        <label>Hora de Término:</label>
        <input type="time" name="final_tempo" required>

        <button type="submit" class="btn-enviar">Publicar Horário</button>
    </form>
</div>

</body>
</html>
 